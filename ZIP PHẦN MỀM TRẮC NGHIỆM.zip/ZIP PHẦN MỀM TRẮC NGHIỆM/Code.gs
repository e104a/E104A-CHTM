const DB = {
  QUESTIONS: 'QUESTIONS',
  SUBJECTS: 'SUBJECTS',
  RESULTS: 'RESULTS',
  SESSIONS: 'SESSIONS',
  SETTINGS: 'SETTINGS',
  EXAMS: 'EXAMS'
};

const HEADERS = {
  QUESTIONS: [
    'ID', 'SUBJECT', 'CHAPTER', 'QUESTION',
    'A', 'B', 'C', 'D', 'CORRECT',
    'EXPLANATION', 'ACTIVE', 'CREATED_AT', 'OPTIONS_JSON'
  ],
  SUBJECTS: ['ID', 'NAME', 'ACTIVE'],
  RESULTS: [
    'ID', 'NAME', 'SUBJECT', 'MODE',
    'TOTAL', 'CORRECT', 'WRONG',
    'SCORE', 'STARTED_AT', 'SUBMITTED_AT',
    'DETAIL_JSON'
  ],
  SESSIONS: [
    'ID', 'NAME', 'SUBJECT', 'MODE',
    'TOTAL', 'STARTED_AT', 'QUESTION_JSON',
    'SUBMITTED', 'PASS_SCORE'
  ],
  SETTINGS: ['KEY', 'VALUE'],
  EXAMS: ['ID','TITLE','SUBJECT_ID','SUBJECT_NAME','QUESTION_IDS','QUESTION_COUNT','MINUTES','PASS_SCORE','STATUS','CREATED_AT']
};

/* 1. MỞ GIAO DIỆN */

function doGet() {
  return HtmlService.createTemplateFromFile('Index')
    .evaluate()
    .setTitle('Phần mềm thi trắc nghiệm')
    .addMetaTag('viewport',
      'width=device-width, initial-scale=1');
}

function include(filename) {
  return HtmlService.createHtmlOutputFromFile(filename)
    .getContent();
}

/* 2. KẾT NỐI CƠ SỞ DỮ LIỆU */

function getSS() {
  // Ưu tiên bảng tính đã lưu ID để cả khi chạy Web App độc lập
  // ứng dụng vẫn kết nối đúng cơ sở dữ liệu.
  const properties = PropertiesService.getScriptProperties();
  const savedId = properties.getProperty('DATABASE_ID');

  if (savedId) {
    return SpreadsheetApp.openById(savedId);
  }

  // Nếu dự án được mở từ một Google Sheets, ghi nhớ ID của bảng tính đó.
  const active = SpreadsheetApp.getActiveSpreadsheet();
  if (active) {
    properties.setProperty('DATABASE_ID', active.getId());
    return active;
  }

  // Chưa có bảng tính được liên kết. Trả về null để setupDatabase tạo mới.
  return null;
}

function getSheet(name) {
  const ss = getSS();
  if (!ss) {
    throw new Error(
      'Chưa có cơ sở dữ liệu Google Sheets. Hãy chạy setupDatabase() một lần để tạo cơ sở dữ liệu.'
    );
  }

  const sh = ss.getSheetByName(name);
  if (!sh) throw new Error('Không tìm thấy trang tính: ' + name);
  return sh;
}

function setupDatabase() {
  let ss = getSS();

  // Với dự án Apps Script độc lập, tự tạo một Google Sheets mới.
  if (!ss) {
    ss = SpreadsheetApp.create('Cơ sở dữ liệu - Phần mềm thi trắc nghiệm');
    PropertiesService.getScriptProperties()
      .setProperty('DATABASE_ID', ss.getId());
  }

  Object.keys(HEADERS).forEach(key => {
    let sh = ss.getSheetByName(DB[key]);

    if (!sh) {
      sh = ss.insertSheet(DB[key]);
    }

    if (sh.getLastRow() === 0) {
      sh.getRange(1, 1, 1, HEADERS[key].length).setValues([HEADERS[key]]);
      sh.getRange(1, 1, 1, HEADERS[key].length).setFontWeight('bold').setBackground('#dbeafe');
      sh.setFrozenRows(1);
    } else {
      const currentHeaders = sh.getRange(1, 1, 1, sh.getLastColumn()).getValues()[0];
      HEADERS[key].forEach((header, index) => {
        if (index >= currentHeaders.length) sh.getRange(1, index + 1).setValue(header);
      });
    }
  });

  // Không tạo sẵn VCX, VKQ, VMH. Ẩn các môn mặc định cũ khỏi danh sách mới,
  // nhưng giữ nguyên câu hỏi/kết quả lịch sử để không mất dữ liệu.
  const subjectSheet = getSheet(DB.SUBJECTS);
  if (subjectSheet.getLastRow() > 1) {
    const subjectRows = subjectSheet.getDataRange().getValues();
    for (let i = 1; i < subjectRows.length; i++) {
      const oldName = String(subjectRows[i][1] || '').trim().toUpperCase();
      if (['VCX','VKQ','VMH'].includes(oldName)) {
        subjectSheet.getRange(i + 1, 3).setValue(false);
      }
    }
  }

  const settings = getSheet(DB.SETTINGS);

  if (settings.getLastRow() === 1) {
    settings.getRange(2, 1, 5, 2).setValues([
      ['ADMIN_PIN', '295295'],
      ['EXAM_COUNT', '50'],
      ['EXAM_MINUTES', '30'],
      ['PASS_SCORE', '5'],
      ['APP_NAME', 'Phần mềm thi trắc nghiệm']
    ]);
  }

  return 'Khởi tạo cơ sở dữ liệu thành công!';
}

/* 3. CÁC HÀM HỖ TRỢ */

function makeId() {
  return Utilities.getUuid();
}

function getRows(sheetName) {
  const sh = getSheet(sheetName);
  const values = sh.getDataRange().getValues();

  if (values.length < 2) return [];

  const headers = values[0];

  return values.slice(1)
    .filter(row => row.some(v => v !== ''))
    .map(row => {
      const obj = {};
      headers.forEach((h, i) => obj[h] = row[i]);
      return obj;
    });
}

function getSetting(key) {
  const rows = getRows(DB.SETTINGS);
  const item = rows.find(r => r.KEY === key);
  return item ? item.VALUE : '';
}

function saveSetting(key, value) {
  const sh = getSheet(DB.SETTINGS);
  const rows = getRows(DB.SETTINGS);

  const index = rows.findIndex(r => r.KEY === key);

  if (index >= 0) {
    sh.getRange(index + 2, 2).setValue(value);
  } else {
    sh.appendRow([key, value]);
  }
}

function checkAdmin(pin) {
  const correctPin = String(getSetting('ADMIN_PIN'));
  if (!pin || String(pin) !== correctPin) {
    throw new Error('Mật khẩu quản trị không chính xác!');
  }
  return true;
}

function shuffleArray(array) {
  const result = array.slice();

  for (let i = result.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [result[i], result[j]] = [result[j], result[i]];
  }

  return result;
}

/* 4. DỮ LIỆU TRANG CHỦ */

function getAppData() {
  const questions = getRows(DB.QUESTIONS)
    .filter(q => q.ACTIVE === true || String(q.ACTIVE) === 'TRUE');

  // Giữ nguyên danh sách môn học thực tế trong cơ sở dữ liệu; chỉ bổ sung
  // số câu hỏi tương ứng để hiển thị trên từng thẻ môn học ở trang chủ.
  const subjects = getRows(DB.SUBJECTS)
    .filter(s => s.ACTIVE === true || String(s.ACTIVE) === 'TRUE')
    .map(s => ({
      id: s.ID,
      name: s.NAME,
      questionCount: questions.filter(q => String(q.SUBJECT || '').trim() === String(s.NAME || '').trim()).length
    }));

  return {
    appName: getSetting('APP_NAME'),
    subjects: subjects,
    exams: getRows(DB.EXAMS).filter(e => String(e.STATUS).toUpperCase() === 'PUBLISHED')
      .map(e => ({id:e.ID, title:e.TITLE, subject:e.SUBJECT_NAME, count:Number(e.QUESTION_COUNT)||0, minutes:Number(e.MINUTES)||0})),
    questionCount: questions.length,
    examCount: Number(getSetting('EXAM_COUNT')) || 50,
    examMinutes: Number(getSetting('EXAM_MINUTES')) || 30
  };
}

/* 4A. ĐỒNG BỘ DANH MỤC MÔN HỌC TỪ DỮ LIỆU ĐÃ CÓ */
function syncSubjectsFromExistingData_() {
  const subjectSheet = getSheet(DB.SUBJECTS);
  const existing = getRows(DB.SUBJECTS);
  const seen = new Set(existing.map(s => String(s.NAME || '').trim().toLocaleLowerCase('vi')));
  const recovered = [];

  // Lấy tên môn từ các bảng đang lưu dữ liệu thực tế; không tự tạo môn mặc định.
  [DB.QUESTIONS, DB.EXAMS, DB.RESULTS, DB.SESSIONS].forEach(sheetName => {
    getRows(sheetName).forEach(row => {
      const candidates = sheetName === DB.EXAMS
        ? [row.SUBJECT_NAME]
        : [row.SUBJECT];
      candidates.forEach(value => {
        const name = String(value || '').trim();
        const key = name.toLocaleLowerCase('vi');
        if (!name || seen.has(key)) return;
        seen.add(key);
        recovered.push([makeId(), name, true]);
      });
    });
  });

  if (recovered.length) {
    subjectSheet.getRange(subjectSheet.getLastRow() + 1, 1, recovered.length, 3)
      .setValues(recovered);
  }
  return recovered.length;
}

/* 5. QUẢN TRỊ NGÂN HÀNG CÂU HỎI */

function adminLogin(pin) {
  checkAdmin(pin);
  return true;
}


/**
 * Chuyển dữ liệu bảng tính thành kiểu dữ liệu an toàn khi truyền
 * từ Apps Script sang trình duyệt qua google.script.run.
 * Đặc biệt chuyển Date thành chuỗi ISO (google.script.run không truyền Date trực tiếp).
 */
function _adminSafeRows_(sheetName) {
  return getRows(sheetName).map(function(row) {
    const safe = {};
    Object.keys(row).forEach(function(key) {
      const value = row[key];
      safe[key] = value instanceof Date
        ? value.toISOString()
        : (value === null || value === undefined ? '' : value);
    });
    return safe;
  });
}

function adminGetData(pin) {
  // Không trả null khi gọi từ Web App: kiểm tra xác thực và trả lỗi rõ ràng
  // qua FailureHandler nếu PIN hoặc cơ sở dữ liệu không hợp lệ.
  checkAdmin(pin);

  // Tự khôi phục danh mục môn học từ dữ liệu cũ nếu SUBJECTS còn thiếu.
  // Không tạo môn mặc định và không sửa/xóa dữ liệu gốc.
  syncSubjectsFromExistingData_();

  const data = {
    questions: _adminSafeRows_(DB.QUESTIONS),
    subjects: _adminSafeRows_(DB.SUBJECTS),
    results: _adminSafeRows_(DB.RESULTS),
    exams: _adminSafeRows_(DB.EXAMS),
    settings: {
      examCount: Number(getSetting('EXAM_COUNT')) || 50,
      examMinutes: Number(getSetting('EXAM_MINUTES')) || 30,
      passScore: Number(getSetting('PASS_SCORE')) || 5
    }
  };

  // Bảo đảm luôn trả về object có đủ các mảng mà giao diện Admin sử dụng.
  if (!Array.isArray(data.subjects)) data.subjects = [];
  if (!Array.isArray(data.questions)) data.questions = [];
  if (!Array.isArray(data.exams)) data.exams = [];
  if (!Array.isArray(data.results)) data.results = [];
  return data;
}

/** Danh sách môn học riêng cho chức năng nhập Word.
 * Không phụ thuộc dữ liệu thống kê/câu hỏi của adminGetData.
 * Giá trị ACTIVE trống được xem là đang hoạt động để tương thích dữ liệu cũ.
 */
function getWordImportSubjects(pin) {
  checkAdmin(pin);
  const rows = getRows(DB.SUBJECTS);
  return rows.map(function(s) {
    const raw = String(s.ACTIVE == null ? '' : s.ACTIVE).trim().toUpperCase();
    const active = !['FALSE', '0', 'NO', 'KHÓA', 'KHOA', 'INACTIVE'].includes(raw);
    return { id: String(s.ID || ''), name: String(s.NAME || '').trim(), active: active };
  }).filter(function(s) { return s.name && s.active; });
}

function _getQuestionOptions_(q) {
  let parsed = [];
  try {
    if (q && q.OPTIONS_JSON) parsed = JSON.parse(String(q.OPTIONS_JSON));
  } catch (e) { parsed = []; }
  if (Array.isArray(parsed) && parsed.length) {
    return parsed.map((item, index) => ({
      key: String(item.key || String.fromCharCode(65 + index)).toUpperCase(),
      text: String(item.text == null ? '' : item.text).trim()
    })).filter(item => item.text);
  }
  return ['A','B','C','D'].map(k => ({key:k, text:String(q && q[k] || '').trim()})).filter(item => item.text);
}

function _optionLetter_(index) {
  return String.fromCharCode(65 + index);
}

function _ensureOptionsColumn_() {
  const sh = getSheet(DB.QUESTIONS);
  const lastCol = Math.max(1, sh.getLastColumn());
  const headers = sh.getRange(1, 1, 1, lastCol).getValues()[0];
  if (headers.indexOf('OPTIONS_JSON') === -1) {
    sh.getRange(1, lastCol + 1).setValue('OPTIONS_JSON');
  }
  return sh;
}

function addQuestion(pin, data) {
  checkAdmin(pin);
  const subject = String(data.subject || '').trim();
  const question = String(data.question || '').trim();
  let options = Array.isArray(data.options) ? data.options : null;
  if (!options) {
    options = ['A','B','C','D'].map(k => ({key:k, text:String(data[k] || '').trim()})).filter(o => o.text);
  }
  options = options.map((o, i) => ({key:String(o.key || _optionLetter_(i)).toUpperCase(), text:String(o.text || '').trim()}));
  const correct = String(data.correct || '').toUpperCase();
  if (!subject || !question) throw new Error('Phải nhập môn học và nội dung câu hỏi.');
  if (options.length < 2) throw new Error('Mỗi câu hỏi phải có ít nhất 2 phương án.');
  if (options.length > 26) throw new Error('Mỗi câu hỏi tối đa 26 phương án (A đến Z).');
  options.forEach((o, i) => {
    if (o.key !== _optionLetter_(i)) throw new Error('Phương án phải liên tục từ A, B, C...');
    if (!o.text) throw new Error('Chưa nhập phương án ' + o.key + '.');
  });
  if (!options.some(o => o.key === correct)) throw new Error('Đáp án đúng phải nằm trong các phương án đã nhập.');
  const byKey = {};
  options.forEach(o => byKey[o.key] = o.text);
  _ensureOptionsColumn_().appendRow([
    makeId(), subject, data.chapter || '', question,
    byKey.A || '', byKey.B || '', byKey.C || '', byKey.D || '',
    correct, data.explanation || '', true, new Date(), JSON.stringify(options)
  ]);
  return 'Đã thêm câu hỏi thành công với ' + options.length + ' phương án!';
}

function updateQuestion(pin, id, data) {
  checkAdmin(pin);
  const sh = _ensureOptionsColumn_();
  const values = sh.getDataRange().getValues();
  const headers = values[0].map(String);
  const rowIndex = values.findIndex((r, i) => i > 0 && String(r[0]) === String(id));
  if (rowIndex < 1) throw new Error('Không tìm thấy câu hỏi.');
  let options = Array.isArray(data.options) ? data.options : null;
  if (!options) options = ['A','B','C','D'].map(k => ({key:k,text:String(data[k] || '').trim()})).filter(o => o.text);
  options = options.map((o,i) => ({key:String(o.key || _optionLetter_(i)).toUpperCase(),text:String(o.text || '').trim()}));
  const correct = String(data.correct || '').toUpperCase();
  if (options.length < 2 || options.length > 26) throw new Error('Câu hỏi phải có từ 2 đến 26 phương án.');
  options.forEach((o,i) => {
    if (o.key !== _optionLetter_(i) || !o.text) throw new Error('Phương án phải liên tục từ A và không được để trống.');
  });
  if (!options.some(o => o.key === correct)) throw new Error('Đáp án đúng không nằm trong các phương án.');
  const byKey = {}; options.forEach(o => byKey[o.key] = o.text);
  const updates = {
    SUBJECT:data.subject, CHAPTER:data.chapter || '', QUESTION:data.question,
    A:byKey.A || '', B:byKey.B || '', C:byKey.C || '', D:byKey.D || '',
    CORRECT:correct, EXPLANATION:data.explanation || '', OPTIONS_JSON:JSON.stringify(options)
  };
  Object.keys(updates).forEach(key => {
    const col = headers.indexOf(key);
    if (col >= 0) sh.getRange(rowIndex + 1, col + 1).setValue(updates[key]);
  });
  return 'Đã cập nhật câu hỏi!';
}

function setQuestionStatus(pin, id, active) {
  checkAdmin(pin);
  const sh = getSheet(DB.QUESTIONS);
  const values = sh.getDataRange().getValues();
  if (!values.length) throw new Error('Ngân hàng câu hỏi chưa có dữ liệu.');
  const headers = values[0].map(String);
  const idCol = headers.indexOf('ID');
  const activeCol = headers.indexOf('ACTIVE');
  if (idCol < 0 || activeCol < 0) throw new Error('Bảng QUESTIONS thiếu cột ID hoặc ACTIVE.');
  const rowIndex = values.findIndex((row, i) => i > 0 && String(row[idCol]) === String(id));
  if (rowIndex < 1) throw new Error('Không tìm thấy câu hỏi.');
  sh.getRange(rowIndex + 1, activeCol + 1).setValue(Boolean(active));
  return Boolean(active) ? 'Đã kích hoạt câu hỏi.' : 'Đã khóa câu hỏi.';
}

function deleteQuestion(pin, id) {
  checkAdmin(pin);

  const sh = getSheet(DB.QUESTIONS);
  const values = sh.getDataRange().getValues();

  const rowIndex = values.findIndex(
    (r, i) => i > 0 && String(r[0]) === String(id)
  );

  if (rowIndex < 1) throw new Error('Không tìm thấy câu hỏi.');

  sh.deleteRow(rowIndex + 1);
  return 'Đã xóa câu hỏi!';
}

/* 6. NHẬP CÂU HỎI TỪ EXCEL */

function importQuestions(pin, textData) {
  checkAdmin(pin);

  const lines = String(textData || '')
    .split(/\r?\n/)
    .filter(line => line.trim());

  let count = 0;

  lines.forEach((line, index) => {
    const c = line.split('\t');

    // Cấu trúc:
    // Môn | Chương | Câu hỏi | A | B | C | D | Đáp án | Giải thích

    if (c.length < 8) {
      throw new Error('Dòng ' + (index + 1) +
        ' không đủ 8 cột dữ liệu.');
    }

    const correct = String(c[7]).trim().toUpperCase();

    if (!['A', 'B', 'C', 'D'].includes(correct)) {
      throw new Error('Đáp án sai tại dòng ' + (index + 1));
    }

    getSheet(DB.QUESTIONS).appendRow([
      makeId(),
      c[0].trim(),
      c[1].trim(),
      c[2].trim(),
      c[3].trim(),
      c[4].trim(),
      c[5].trim(),
      c[6].trim(),
      correct,
      c[8] || '',
      true,
      new Date()
    ]);

    count++;
  });

  return 'Đã nhập thành công ' + count + ' câu hỏi!';
}

/* 7. QUẢN LÝ MÔN HỌC */

function addSubject(pin, name) {
  checkAdmin(pin);

  name = String(name || '').trim();

  if (!name) throw new Error('Tên môn học không được để trống.');

  const subjects = getRows(DB.SUBJECTS);

  if (subjects.some(s =>
    String(s.NAME).toLowerCase() === name.toLowerCase()
  )) {
    throw new Error('Môn học đã tồn tại.');
  }

  getSheet(DB.SUBJECTS).appendRow([
    makeId(), name, true
  ]);

  return 'Đã thêm môn học!';
}


/* 7A. QUẢN LÝ MÔN HỌC */
function updateSubject(pin, id, name, active) {
  checkAdmin(pin);
  name = String(name || '').trim();
  if (!name) throw new Error('Tên môn học không được để trống.');
  const sh = getSheet(DB.SUBJECTS);
  const values = sh.getDataRange().getValues();
  const row = values.findIndex((r,i) => i > 0 && String(r[0]) === String(id));
  if (row < 1) throw new Error('Không tìm thấy môn học.');
  const duplicate = values.slice(1).some((r,i) => i + 1 !== row && String(r[1]).toLowerCase() === name.toLowerCase());
  if (duplicate) throw new Error('Tên môn học đã tồn tại.');
  sh.getRange(row + 1, 2).setValue(name);
  sh.getRange(row + 1, 3).setValue(active !== false);
  return 'Đã cập nhật môn học.';
}
function deleteSubject(pin, id) {
  checkAdmin(pin);
  const sh = getSheet(DB.SUBJECTS);
  const values = sh.getDataRange().getValues();
  const row = values.findIndex((r,i) => i > 0 && String(r[0]) === String(id));
  if (row < 1) throw new Error('Không tìm thấy môn học.');
  const name = String(values[row][1]);
  const used = getRows(DB.QUESTIONS).some(q => String(q.SUBJECT) === name);
  const usedExam = getRows(DB.EXAMS).some(e => String(e.SUBJECT_ID) === String(id));
  if (used || usedExam) {
    sh.getRange(row + 1, 3).setValue(false);
    return 'Môn học đã có dữ liệu nên được khóa, không xóa hẳn.';
  }
  sh.deleteRow(row + 1);
  return 'Đã xóa môn học.';
}

/* 7B. TẠO VÀ QUẢN LÝ ĐỀ THI */
function createExam(pin, data) {
  checkAdmin(pin);
  const title = String(data.title || '').trim();
  const subjectId = String(data.subjectId || '');
  const count = Number(data.count);
  const minutes = Number(data.minutes);
  const pass = Number(data.passScore);
  const subject = getRows(DB.SUBJECTS).find(s => String(s.ID) === subjectId && (s.ACTIVE === true || String(s.ACTIVE).toUpperCase() === 'TRUE'));
  if (!title) throw new Error('Hãy nhập tên đề thi.');
  if (!subject) throw new Error('Hãy chọn môn học hợp lệ.');
  if (!Number.isInteger(count) || count < 1) throw new Error('Số câu hỏi phải từ 1 trở lên.');
  if (!Number.isInteger(minutes) || minutes < 1) throw new Error('Thời gian thi phải từ 1 phút.');
  if (!Number.isFinite(pass) || pass < 0 || pass > 10) throw new Error('Điểm đạt phải từ 0 đến 10.');
  const bank = getRows(DB.QUESTIONS).filter(q => String(q.SUBJECT) === String(subject.NAME) && (q.ACTIVE === true || String(q.ACTIVE).toUpperCase() === 'TRUE'));
  if (bank.length < count) throw new Error('Ngân hàng môn này chỉ có ' + bank.length + ' câu hỏi đang hoạt động.');
  const ids = data.questionIds && data.questionIds.length
    ? data.questionIds.map(String)
    : [];
  if (ids.length && ids.length !== count) throw new Error('Số câu đã chọn phải bằng số câu của đề.');
  if (ids.some(id => !bank.some(q => String(q.ID) === id))) throw new Error('Có câu hỏi không thuộc môn học đã chọn.');
  const status = String(data.status || 'DRAFT') === 'PUBLISHED' ? 'PUBLISHED' : 'DRAFT';
  const id = makeId();
  getSheet(DB.EXAMS).appendRow([id,title,subjectId,subject.NAME,JSON.stringify(ids),count,minutes,pass,status,new Date()]);
  return 'Đã tạo đề thi "' + title + '".';
}
function setExamStatus(pin, id, status) {
  checkAdmin(pin);
  if (!['DRAFT','PUBLISHED','LOCKED'].includes(String(status))) throw new Error('Trạng thái đề thi không hợp lệ.');
  const sh = getSheet(DB.EXAMS), values = sh.getDataRange().getValues();
  const row = values.findIndex((r,i) => i > 0 && String(r[0]) === String(id));
  if (row < 1) throw new Error('Không tìm thấy đề thi.');
  sh.getRange(row + 1, 9).setValue(status);
  return 'Đã cập nhật trạng thái đề thi.';
}
function deleteExam(pin, id) {
  checkAdmin(pin);
  const sh = getSheet(DB.EXAMS), values = sh.getDataRange().getValues();
  const row = values.findIndex((r,i) => i > 0 && String(r[0]) === String(id));
  if (row < 1) throw new Error('Không tìm thấy đề thi.');
  sh.deleteRow(row + 1);
  return 'Đã xóa đề thi.';
}

/* 8. CẤU HÌNH THI */

function updateSettings(pin, data) {
  checkAdmin(pin);

  const count = Number(data.examCount);
  const minutes = Number(data.examMinutes);
  const pass = Number(data.passScore);

  if (!Number.isInteger(count) || count < 1) {
    throw new Error('Số câu thi không hợp lệ.');
  }

  if (!Number.isInteger(minutes) || minutes < 1) {
    throw new Error('Thời gian thi không hợp lệ.');
  }

  if (!Number.isFinite(pass) || pass < 0 || pass > 10) {
    throw new Error('Điểm đạt không hợp lệ.');
  }

  saveSetting('EXAM_COUNT', count);
  saveSetting('EXAM_MINUTES', minutes);
  saveSetting('PASS_SCORE', pass);

  return 'Đã lưu cấu hình!';
}

function changeAdminPin(oldPin, newPin) {
  checkAdmin(oldPin);

  newPin = String(newPin || '');

  if (newPin.length < 6) {
    throw new Error('Mật khẩu mới phải có ít nhất 6 ký tự.');
  }

  saveSetting('ADMIN_PIN', newPin);

  return 'Đã đổi mật khẩu quản trị!';
}

/* 9. BẮT ĐẦU BÀI THI */

function startQuiz(data) {
  const name = String(data.name || '').trim();
  const subject = String(data.subject || '').trim();
  const mode = String(data.mode || '').trim();

  if (!name) throw new Error('Bạn chưa nhập họ tên.');
  if (!subject) throw new Error('Bạn chưa chọn môn học.');
  if (!['practice', 'exam'].includes(mode)) {
    throw new Error('Chế độ thi không hợp lệ.');
  }

  let questions = getRows(DB.QUESTIONS)
    .filter(q => String(q.SUBJECT) === subject &&
      (q.ACTIVE === true || String(q.ACTIVE).toUpperCase() === 'TRUE'));
  let examMinutes = Number(getSetting('EXAM_MINUTES')) || 30;
  let examPassScore = Number(getSetting('PASS_SCORE')) || 5;

  if (mode === 'exam' && data.examId) {
    const exam = getRows(DB.EXAMS).find(e => String(e.ID) === String(data.examId) && String(e.STATUS) === 'PUBLISHED');
    if (!exam) throw new Error('Đề thi không tồn tại hoặc chưa được công khai.');
    if (String(exam.SUBJECT_NAME) !== subject) throw new Error('Môn học của đề thi không khớp.');
    const ids = JSON.parse(exam.QUESTION_IDS || '[]').map(String);
    if (ids.length) questions = questions.filter(q => ids.includes(String(q.ID)));
    else questions = shuffleArray(questions).slice(0, Number(exam.QUESTION_COUNT));
    examMinutes = Number(exam.MINUTES) || examMinutes;
    examPassScore = Number(exam.PASS_SCORE) || examPassScore;
  }

  if (!questions.length) throw new Error('Ngân hàng môn này không có câu hỏi đang hoạt động.');

  // LUYỆN TẬP: sắp xếp theo PRACTICE_ORDER đã lưu trong QUESTIONS.
  // Nếu một câu chưa có PRACTICE_ORDER, giữ vị trí tương đối theo dòng sheet
  // (không tự tạo/ghi lại thứ tự, tránh làm sai thứ tự nguồn đã khôi phục).
  // THI KIỂM TRA: vẫn xáo trộn ngẫu nhiên như chức năng hiện có.
  if (mode === 'practice') {
    questions = questions.map((q, index) => ({
      q: q,
      originalIndex: index,
      order: Number(q.PRACTICE_ORDER)
    })).sort((a, b) => {
      const aValid = Number.isFinite(a.order) && a.order > 0;
      const bValid = Number.isFinite(b.order) && b.order > 0;
      if (aValid && bValid) return a.order - b.order || a.originalIndex - b.originalIndex;
      if (aValid) return -1;
      if (bValid) return 1;
      return a.originalIndex - b.originalIndex;
    }).map(item => item.q);
  } else {
    questions = shuffleArray(questions);
  }

  const configuredCount = Number(getSetting('EXAM_COUNT')) || 30;
  const requestedCount = Number(data.count) || configuredCount;
  const total = mode === 'practice'
    ? questions.length
    : Math.min(questions.length, requestedCount);
  questions = questions.slice(0, total);

  const sessionId = makeId();
  const startedAt = new Date();

  const snapshot = questions.map(q => {
    const options = _getQuestionOptions_(q);
    const item = {
      id: String(q.ID), question: String(q.QUESTION), options: options,
      correct: String(q.CORRECT).toUpperCase(),
      explanation: String(q.EXPLANATION || '')
    };
    options.forEach(o => item[o.key] = o.text);
    return item;
  });

  getSheet(DB.SESSIONS).appendRow([
    sessionId,
    name,
    subject,
    mode,
    total,
    startedAt,
    JSON.stringify(snapshot),
    false,
    examPassScore
  ]);

  const clientQuestions = snapshot.map(q => {
    const item = {
      id: q.id,
      question: q.question,
      options: q.options
    };
    q.options.forEach(o => item[o.key] = o.text);

    if (mode === 'practice') {
      item.correct = q.correct;
      item.explanation = q.explanation;
    }

    return item;
  });

  return {
    sessionId: sessionId,
    name: name,
    subject: subject,
    mode: mode,
    total: total,
    minutes: mode === 'exam' ? examMinutes : 0,
    questions: clientQuestions
  };
}

/* 10. NỘP BÀI VÀ CHẤM ĐIỂM */

function submitQuiz(sessionId, answers) {
  const lock = LockService.getScriptLock();
  lock.waitLock(10000);

  try {
    const sh = getSheet(DB.SESSIONS);
    const values = sh.getDataRange().getValues();

    const index = values.findIndex(
      (r, i) => i > 0 && String(r[0]) === String(sessionId)
    );

    if (index < 1) throw new Error('Không tìm thấy bài thi.');

    const row = values[index];

    if (String(row[7]) === 'true' ||
        row[7] === true) {
      throw new Error('Bài thi đã được nộp trước đó.');
    }

    const questions = JSON.parse(row[6]);
    const total = questions.length;

    let correct = 0;
    const details = [];

    questions.forEach(q => {
      const answer = String(
        answers && answers[q.id] || ''
      ).toUpperCase();

      const isCorrect = answer === q.correct;

      if (isCorrect) correct++;

      details.push({
        questionId: q.id,
        question: q.question,
        selected: answer,
        correct: q.correct,
        isCorrect: isCorrect
      });
    });

    const wrong = total - correct;
    const score = total
      ? Math.round(correct / total * 1000) / 100
      : 0;

    const submittedAt = new Date();

    getSheet(DB.RESULTS).appendRow([
      makeId(),
      row[1],
      row[2],
      row[3],
      total,
      correct,
      wrong,
      score,
      row[5],
      submittedAt,
      JSON.stringify(details)
    ]);

    sh.getRange(index + 1, 8).setValue(true);

    return {
      name: row[1],
      subject: row[2],
      mode: row[3],
      total: total,
      correct: correct,
      wrong: wrong,
      unanswered: details.filter(d => !d.selected).length,
      score: score,
      pass: score >= Number(row[8] || getSetting('PASS_SCORE') || 5),
      details: details
    };

  } finally {
    lock.releaseLock();
  }
}

/* 11. XEM LỊCH SỬ VÀ THỐNG KÊ */

function getPublicResults(name) {
  name = String(name || '').trim().toLowerCase();

  return getRows(DB.RESULTS)
    .filter(r => String(r.NAME).trim().toLowerCase() === name)
    .map(r => ({
      name: r.NAME,
      subject: r.SUBJECT,
      mode: r.MODE,
      total: r.TOTAL,
      correct: r.CORRECT,
      wrong: r.WRONG,
      score: r.SCORE,
      submittedAt: r.SUBMITTED_AT
    }));
}

function getAdminStatistics(pin) {
  checkAdmin(pin);

  const results = getRows(DB.RESULTS);

  const total = results.length;
  const average = total
    ? results.reduce((sum, r) => sum + Number(r.SCORE || 0), 0) / total
    : 0;

  return {
    total: total,
    average: Math.round(average * 100) / 100,
    results: results
  };
}

/* NHẬP CÂU HỎI TỪ TỆP WORD/TÀI LIỆU TƯƠNG THÍCH - CẦN BẬT ADVANCED DRIVE SERVICE */
function previewWordQuestions(pin, fileName, base64Data, subject, fileMimeType) {
  checkAdmin(pin);
  subject = String(subject || '').trim();
  if (!subject) throw new Error('Hãy chọn môn học trước khi tải Word.');
  if (!fileName) throw new Error('Không xác định được tên tệp.');
  if (!base64Data) throw new Error('File Word không có dữ liệu.');
  if (base64Data.length > 14 * 1024 * 1024) throw new Error('File quá lớn. Vui lòng dùng file dưới khoảng 10 MB.');

  const bytes = Utilities.base64Decode(base64Data);
  const ext = String(fileName).split('.').pop().toLowerCase();
  const mimeByExt = {
    docx:'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    doc:'application/msword',
    docm:'application/vnd.ms-word.document.macroEnabled.12',
    dotx:'application/vnd.openxmlformats-officedocument.wordprocessingml.template',
    dot:'application/msword',
    rtf:'application/rtf',
    odt:'application/vnd.oasis.opendocument.text',
    txt:'text/plain'
  };
  const suppliedMime = String(fileMimeType || '').trim();
  const mime = (!suppliedMime || suppliedMime === 'application/octet-stream')
    ? (mimeByExt[ext] || 'application/octet-stream') : suppliedMime;
  const blob = Utilities.newBlob(bytes, mime, fileName);
  let convertedId = '';
  try {
    // Advanced Google service: Drive API v3. Tạo bản Google Docs tạm để đọc cả nội dung và định dạng.
    const converted = Drive.Files.create({
      name: 'TMP_WORD_IMPORT_' + new Date().getTime(),
      mimeType: 'application/vnd.google-apps.document'
    }, blob, {fields: 'id'});
    convertedId = converted.id;
    const doc = DocumentApp.openById(convertedId);
    const paragraphs = [];
    _collectWordParagraphs_(doc.getBody(), paragraphs);
    const parsed = _parseWordQuestionParagraphs_(paragraphs);
    if (!parsed.length) {
      const sample = paragraphs.slice(0, 12).map(p => String(p.text || '').trim()).filter(Boolean).join(' | ').slice(0, 700);
      throw new Error('Đã đọc được tệp nhưng chưa nhận dạng được cấu trúc câu hỏi. Hỗ trợ dạng Câu 1: ...; 1. ...; phương án A., A), (A), A:; mỗi câu cần ít nhất 2 phương án. Nội dung đầu tệp đọc được: ' + (sample || '[không đọc được văn bản]'));
    }
    const token = Utilities.getUuid();
    CacheService.getUserCache().put('WORD_IMPORT_' + token, JSON.stringify({subject:subject, questions:parsed}), 1800);
    return {
      token: token,
      subject: subject,
      total: parsed.length,
      ready: parsed.filter(q => q.correct && !q.needsReview).length,
      review: parsed.filter(q => !q.correct || q.needsReview).length,
      questions: parsed
    };
  } finally {
    if (convertedId) {
      try { Drive.Files.delete(convertedId); } catch (e) {}
    }
  }
}

function _collectWordParagraphs_(element, out) {
  const type = element.getType();
  if (type === DocumentApp.ElementType.PARAGRAPH || type === DocumentApp.ElementType.LIST_ITEM) {
    const p = type === DocumentApp.ElementType.PARAGRAPH
      ? element.asParagraph() : element.asListItem();
    const text = p.getText();
    if (text && text.trim()) {
      const cleanText = text.trim();
      // Chỉ đọc định dạng ở các đoạn có khả năng là phương án A-Z.
      // Không gọi getAttributes() cho từng ký tự của toàn bộ tài liệu.
      const isOption = /^(?:[A-Z]\s*[.、):\-]|\([A-Z]\)\s*)/i.test(cleanText);
      let marked = false;
      if (isOption) marked = _hasWordOptionFormatting_(p);
      out.push({ text: cleanText, marked: marked });
    }
    return;
  }
  if (element.getNumChildren) {
    const count = element.getNumChildren();
    for (let i = 0; i < count; i++) _collectWordParagraphs_(element.getChild(i), out);
  }
}

function _hasWordOptionFormatting_(paragraph) {
  try {
    const text = paragraph.editAsText();
    const content = text.getText();
    if (!content) return false;

    // Google Docs sau khi chuyển đổi DOCX có thể biểu diễn định dạng
    // bằng nhiều TextRun. Lấy các điểm bắt đầu vùng định dạng, đồng thời
    // kiểm tra trực tiếp isBold/getForegroundColor để tránh bỏ sót thuộc tính.
    let indexes = [];
    try { indexes = text.getTextAttributeIndices() || []; } catch (e) {}
    indexes = [0].concat(indexes).filter((v, i, a) =>
      Number.isInteger(Number(v)) && Number(v) >= 0 && Number(v) < content.length && a.indexOf(v) === i
    );

    for (let i = 0; i < indexes.length; i++) {
      const offset = Number(indexes[i]);
      let bold = false;
      let color = '';
      try { bold = text.isBold(offset) === true; } catch (e) {}
      try { color = String(text.getForegroundColor(offset) || '').toLowerCase(); } catch (e) {}

      // Dự phòng theo Attributes vì một số tài liệu chuyển đổi không trả
      // đầy đủ qua các hàm isBold/getForegroundColor.
      try {
        const attrs = text.getAttributes(offset) || {};
        bold = bold || attrs.BOLD === true;
        if (!color && attrs.FOREGROUND_COLOR) {
          color = String(attrs.FOREGROUND_COLOR).toLowerCase();
        }
      } catch (e) {}

      const isRed = color === '#ff0000' || color === 'ff0000' ||
        color === 'red' || color === '#f00' || color === 'f00';

      // Tệp nguồn đánh dấu đáp án đúng bằng chữ đỏ + in đậm.
      // Chấp nhận từng tín hiệu độc lập để không mất đáp án nếu Drive
      // chỉ giữ lại một thuộc tính định dạng trong quá trình chuyển DOCX.
      if (bold || isRed) return true;
    }
  } catch (e) {
    // Không đọc được định dạng thì giữ nội dung; câu sẽ cần rà soát thủ công.
  }
  return false;
}

function _parseWordQuestionParagraphs_(paragraphs) {
  const result = [];
  let cur = null;

  function startQuestion(text) {
    finish();
    cur = {question:String(text || '').trim(), options:{}, optionMarks:{}, explicit:'', explanation:''};
  }

  function finish() {
    if (!cur) return;
    const keys = Object.keys(cur.options).sort();
    const validSequence = keys.length >= 2 && keys.length <= 26 &&
      keys.every((key, index) => key === _optionLetter_(index)) &&
      keys.every(key => String(cur.options[key] || '').trim());
    if (cur.question && validSequence) {
      const marked = keys.filter(k => cur.optionMarks[k]);
      const explicitValid = keys.includes(cur.explicit);
      const correct = explicitValid ? cur.explicit : (marked.length === 1 ? marked[0] : '');
      const uncertain = !explicitValid && marked.length !== 1;
      const options = keys.map(key => ({key:key, text:cur.options[key]}));
      const item = {
        question:cur.question, options:options, correct:correct,
        explanation:cur.explanation || '', needsReview:uncertain,
        detection:explicitValid ? 'Dòng đáp án đúng' : (marked.length ? 'Định dạng Word' : 'Chưa xác định')
      };
      options.forEach(o => item[o.key] = o.text);
      result.push(item);
    }
    cur = null;
  }

  function processLine(raw, marked) {
    let t = String(raw || '').replace(/[\u00a0\u200b]/g, ' ').replace(/[\t\r]+/g, ' ').replace(/\s{2,}/g, ' ').trim();
    if (!t) return;

    // Nhận diện nhiều cách đánh số câu: "Câu 1", "Câu hỏi 1", "1.", "1)".
    let qm = t.match(/^(?:Câu(?:\s*hỏi)?\s*)?(\d{1,4})\s*[).:\-、]\s*(.*)$/i);
    let qword = t.match(/^Câu(?:\s*hỏi)?\s*(\d+)\s*[:：.\-、]?\s*(.*)$/i);
    if (qword) { startQuestion(qword[2]); return; }
    if (qm && !/^[A-Z]\s*[).:\-]/i.test(t)) { startQuestion(qm[2]); return; }
    if (!cur) return;

    let am = t.match(/^(?:Đáp\s*án(?:\s*đúng)?|ĐA|Answer|Correct\s*answer)\s*[:：=\-]?\s*\(?([A-Z])\)?\s*[.)]?(?:\s|$)/i);
    if (am) { cur.explicit = am[1].toUpperCase(); return; }
    let ex = t.match(/^(?:Giải thích|Giải đáp|Lời giải)\s*[:：]\s*(.*)$/i);
    if (ex) { cur.explanation = ex[1]; return; }

    // Tách được cả trường hợp nhiều phương án nằm trên cùng một dòng:
    // "A. ... B. ... C. ..." hoặc "(A) ... (B) ...".
    const tokenRe = /(?:^|\s)(?:\(([A-Z])\)|([A-Z])\s*[.、):\-])\s*/g;
    const tokens = [];
    let m;
    while ((m = tokenRe.exec(t)) !== null) {
      const key = (m[1] || m[2] || '').toUpperCase();
      const tokenStart = m.index + (m[0].length - m[0].trimStart().length);
      tokens.push({key:key, start:tokenStart, end:tokenRe.lastIndex});
    }
    if (tokens.length) {
      // Chỉ coi là danh sách phương án nếu bắt đầu từ A hoặc tiếp tục đúng thứ tự.
      const first = tokens[0].key;
      const existing = Object.keys(cur.options).length;
      if (first === 'A' || first === _optionLetter_(existing)) {
        tokens.forEach((tok, i) => {
          const expected = _optionLetter_(existing + i);
          if (tok.key !== expected) return;
          const nextStart = i + 1 < tokens.length ? tokens[i + 1].start : t.length;
          const value = t.substring(tok.end, nextStart).trim();
          if (value) {
            cur.options[tok.key] = value;
            cur.optionMarks[tok.key] = marked === true;
          }
        });
        return;
      }
    }

    // Dạng phương án riêng từng dòng, có thể là A. / A) / (A) / A:
    const om = t.match(/^(?:\(([A-Z])\)|([A-Z])\s*[.、):\-])\s*(.*)$/i);
    if (om) {
      const key = (om[1] || om[2]).toUpperCase();
      const value = String(om[3] || '').trim();
      if (value) {
        cur.options[key] = value;
        cur.optionMarks[key] = marked === true;
      }
      return;
    }

    // Nếu câu hỏi bị xuống dòng thành nhiều đoạn trước phương án đầu tiên, ghép lại.
    if (!Object.keys(cur.options).length) cur.question += (cur.question ? '\n' : '') + t;
    else {
      const lastKey = Object.keys(cur.options).sort().slice(-1)[0];
      cur.options[lastKey] += '\n' + t;
    }
  }

  (paragraphs || []).forEach(p => {
    const raw = String(p && p.text || '');
    // Tài liệu Word có thể chứa xuống dòng mềm trong cùng một Paragraph.
    raw.split(/\n+/).forEach(line => processLine(line, p && p.marked === true));
  });
  finish();
  return result;
}

function confirmWordImport(pin, token, selectedIndexes) {
  checkAdmin(pin);
  const key = 'WORD_IMPORT_' + token;
  const raw = CacheService.getUserCache().get(key);
  if (!raw) throw new Error('Phiên xem trước đã hết hạn. Hãy tải lại tệp và phân tích lại.');
  const pack = JSON.parse(raw);
  const indexes = Array.isArray(selectedIndexes) ? selectedIndexes : [];
  if (!indexes.length) throw new Error('Chưa chọn câu hỏi nào để nhập.');
  const sh = _ensureOptionsColumn_();
  const rows = [];
  indexes.forEach(i => {
    const q = pack.questions[Number(i)];
    if (!q || !Array.isArray(q.options) || q.options.length < 2) return;

    // Chỉ chấp nhận danh sách liên tục A, B, C... và đáp án nằm trong danh sách đó.
    const optionKeys = q.options.map((o, index) =>
      String(o && o.key || _optionLetter_(index)).toUpperCase()
    );
    const validSequence = optionKeys.every((key, index) => key === _optionLetter_(index));
    const correctKey = String(q.correct || '').toUpperCase();
    if (!validSequence || !optionKeys.includes(correctKey)) return;

    const byKey = {};
    q.options.forEach((o, index) => {
      const key = optionKeys[index];
      const value = String(o && o.text == null ? '' : o.text).trim();
      if (value) byKey[key] = value;
    });
    if (Object.keys(byKey).length !== q.options.length || !byKey[correctKey]) return;
    rows.push([
      makeId(), pack.subject, '', q.question,
      byKey.A || '', byKey.B || '', byKey.C || '', byKey.D || '',
      correctKey, q.explanation || '', true, new Date(), JSON.stringify(q.options.map((o, index) => ({key: optionKeys[index], text: String(o.text || '').trim()})))
    ]);
  });
  if (!rows.length) throw new Error('Không có câu hỏi hợp lệ. Mỗi câu phải có ít nhất 2 phương án và đáp án đúng phải nằm trong các phương án đó.');
  sh.getRange(sh.getLastRow() + 1, 1, rows.length, rows[0].length).setValues(rows);
  CacheService.getUserCache().remove(key);
  return 'Đã nhập thành công ' + rows.length + ' câu hỏi vào môn ' + pack.subject + '. Số phương án từng câu được giữ nguyên.';
}
function kiemTraCoSoDuLieu() {
  const ss = getSS();
  if (!ss) throw new Error('Không tìm thấy cơ sở dữ liệu.');

  const sh = ss.getSheetByName('SUBJECTS');

  Logger.log('Tên bảng tính: ' + ss.getName());
  Logger.log('ID bảng tính: ' + ss.getId());
  Logger.log('URL bảng tính: ' + ss.getUrl());

  if (!sh) {
    Logger.log('KHÔNG CÓ SHEET SUBJECTS');
    return;
  }

  Logger.log('Số dòng SUBJECTS: ' + sh.getLastRow());
  Logger.log('Dữ liệu SUBJECTS: ' +
    JSON.stringify(sh.getDataRange().getDisplayValues()));
}
function kiemTraDuLieuAdmin() {
  const pin = getSetting('ADMIN_PIN');
  const data = adminGetData(pin);

  Logger.log('Số môn học Admin nhận được: ' +
    (data.subjects ? data.subjects.length : 'KHÔNG CÓ'));

  Logger.log('Danh sách môn học Admin nhận được: ' +
    JSON.stringify(data.subjects));

  Logger.log('Số câu hỏi: ' + data.questions.length);
  Logger.log('Số đề thi: ' + data.exams.length);
  Logger.log('Số kết quả: ' + data.results.length);
}